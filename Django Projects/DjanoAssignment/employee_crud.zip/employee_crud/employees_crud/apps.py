from django.apps import AppConfig


class EmployeeCrudConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'employees_crud'
